import pygame
import os
import constantes as cts

pygame.init()

class setas(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        pygame.sprite.Sprite.__init__(self)
        self.ss_prot = pygame.image.load(os.path.join(cts.dir_imagens, "ss_prot.png")).convert_alpha()
        self.image = self.ss_prot.subsurface((0, 0), (17, 28))
        self.rect = self.image.get_rect()
        self.rect.center = (pos_x, pos_y)