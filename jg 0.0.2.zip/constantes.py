import pygame
import os
pygame.init()
# Cores
VERMELHO = (255, 0, 0)
VERDE = (49, 196, 108)
AZUL = (0, 0, 255)
AMARELO = (254, 223, 0)
AMARELO2 = (255, 245, 0)
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)

# Parâmetros, tela
NOME_DA_TELA = "Teste03"
LARGURA = 1024
ALTURA = 768
FPS = 30

# Fontes
ARIAL = "arial"
FONTE = pygame.font.match_font(ARIAL)  # Fonte usada

# Imagens
dir_imagens = os.path.join(os.path.dirname(__file__), "Imagens")
ICON_TELA = "icon_tela.png"
# Logo
LOGO_NOME = "icon_tela.png"
logo = os.path.join(dir_imagens, LOGO_NOME)

def pega_imagem(nome_imagem):
    img = pygame.image.load(os.path.join(dir_imagens, nome_imagem)).convert_alpha()
    img = img.subsurface((0, 0), (32, 32))
    return img


def mostrar_texto(tela, tamanho, texto, cor, x, y, neg):
    # Exibe uma mensagem na tela
    fonte = pygame.font.SysFont(FONTE, tamanho, neg)
    texto = fonte.render(texto, True, cor)
    texto_rect = texto.get_rect()
    texto_rect.midtop = (x, y)
    tela.blit(texto, texto_rect)
