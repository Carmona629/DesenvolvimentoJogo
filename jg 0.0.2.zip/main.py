import pygame
import constantes as cts
import sprites as sts

class Jogo:
    def __init__(self):
        # Criando tela
        pygame.init()  # Inicia pygame
        self.tela = pygame.display.set_mode((cts.LARGURA, cts.ALTURA), pygame.SCALED)  # Cria tela
        pygame.display.set_caption(cts.NOME_DA_TELA)  # Define nome da tela
        self.relogio = pygame.time.Clock()  # FPS
        self.jogando = True

    def rodar(self):
        # Loop principal do jogo
        while self.jogando:
            self.relogio.tick(cts.FPS)
            self.eventos()
            self.menu_inicial()

    def eventos(self):
        # Define os eventos do jogo
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.jogando = False

    def desenhar_seta(self, pos_x, pos_y):
        self.setas = pygame.sprite.Group()
        self.seta_inicial = sts.setas(pos_x, pos_y)
        self.setas.add(self.seta_inicial)
        self.setas.draw(self.tela)

    def menu_inicial(self):
        # Variaveis
        valor_x = [420, 419, 410, 465]
        i = 0
        pos_x = valor_x[i]
        pos_y = (cts.ALTURA // 2) + 10

        self.tela.fill(cts.AMARELO)
        # Logo
        logo = pygame.image.load(cts.logo).convert_alpha()
        logo = pygame.transform.scale(logo, (17 * 10, 28 * 10))
        logo1 = logo.get_rect()
        logo1.midtop = (cts.LARGURA // 2, 20)
        self.tela.blit(logo, logo1)

        # Opções do menu
        cts.mostrar_texto(self.tela, 40, "Novo Jogo", cts.PRETO, cts.LARGURA // 2, cts.ALTURA // 2, True)
        cts.mostrar_texto(self.tela, 40, "Continuar", cts.PRETO, cts.LARGURA // 2, 420, True)
        cts.mostrar_texto(self.tela, 40, "Configurar", cts.PRETO, cts.LARGURA // 2, 455, True)
        cts.mostrar_texto(self.tela, 40, "Sair", cts.PRETO, cts.LARGURA // 2, 490, True)
        cts.mostrar_texto(self.tela, 22, "Desenvolvido por Guilherme Carmona", cts.PRETO, cts.LARGURA // 2, cts.ALTURA - 20, False)

        self.desenhar_seta(pos_x, pos_y)
        """for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                # Movimentos, seleção
                if event.key == pygame.K_s:
                    pos_y += 35
                    i += 1
                    if i > len(valor_x) - 1:
                        i = 0
                    pos_x = valor_x[i]
                    if pos_y > 499:
                        pos_y = (cts.ALTURA // 2) + 10
                if event.key == pygame.K_w:
                    pos_y -= 35
                    i -= 1
                    if i < 0:
                        i = len(valor_x) - 1
                    pos_x = valor_x[i]
                    if pos_y < (cts.ALTURA // 2) + 10:
                        pos_y = 499"""

        pygame.display.flip()


jogo = Jogo()

while jogo.jogando:
    jogo.rodar()
