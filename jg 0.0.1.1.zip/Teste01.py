import pygame
from pygame.locals import *
from sys import exit
import os
import TesteMapa01
from random import randrange

# Diretórios
dir_principal = os.path.dirname(__file__)
dir_imagens = os.path.join(dir_principal, "Imagens")
dir_sons = os.path.join(dir_principal, "Sons")

pygame.init()
pygame.mixer.init()

# Cores
vermelho = (255, 0, 0)
verde = (0, 255, 0)
azul = (0, 0, 2555)
preto = (0, 0, 0)
branco = (255, 255, 255)

# Parâmetros tela
pygame.display.init()
nome_da_tela = "TestesMapa"
largura = 1024
altura = 768
tela = pygame.display.set_mode((largura, altura), pygame.RESIZABLE)
icon = pygame.image.load(os.path.join(dir_imagens, "icon_tela.png")).convert_alpha()
pygame.display.set_icon(icon)
pygame.display.set_caption(nome_da_tela)
relogio = pygame.time.Clock()
FPS = 30
velocidade = 4

# Carregar sprites
ss_grama = pygame.image.load(os.path.join(dir_imagens, "ss_grama.png")).convert_alpha()
ss_terra = pygame.image.load(os.path.join(dir_imagens, "ss_terra.png")).convert_alpha()
ss_prot = pygame.image.load(os.path.join(dir_imagens, "ss_prot.png")).convert_alpha()

# Escalas blocos
prop_x = largura / 1024  # Passo a passo: (largura / 32) / 32 => multiplica pelo inverso da segunda: largura * 1 / 32 * 32 = > largura / 1024
prop_y = altura / 768  # passo a passo: (altura / 24) / 32 => multiplica pelo inverso da segunda: altura * 1 / 24 * 32 = > altura / 768

block_largura = largura // 32
block_altura = altura // 24

# Classes e funções
def desenha_mapa(mapa, caracter_imagem):
    for n_linha, linha in enumerate(mapa):
        for n_coluna, char in enumerate(linha):
            x = n_coluna * block_largura
            y = n_linha * block_altura
            img = caracter_imagem[char]
            tela.blit(img, (x, y))

def teste_colisao_mapa(personagem, mapa, lista_caracteres):    # Testa se o lugar para onde o player quer ir tem algo que existe colisão
    colisoes = []
    for n_linha, linha in enumerate(mapa):
        for n_coluna, char in enumerate(linha):
            if char in lista_caracteres:
                x = n_coluna * block_largura
                y = n_linha * block_altura
                rect_teste = pygame.Rect((x, y), (block_largura, block_altura))  # Recebe a posição do bloco a frente
                rect_teste2 = personagem.rect.copy()
                rect_teste2.move_ip(personagem.vel_x, personagem.vel_y)  # Recebe o bloco que o jogador quer andar
                if rect_teste.colliderect(rect_teste2):
                    colisao = {"Coluna": n_coluna, "Linha": n_linha, "Caracter": char}
                    colisoes.append(colisao)
    return colisoes

class Prot(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.todas_as_imagens = []
        self.imagens_frente = []
        for x in range(4):
            img = ss_prot.subsurface((x * 17, 0), (17, 28))
            self.imagens_frente.append(img)
            self.todas_as_imagens.append(img)
        self.img = ss_prot.subsurface((0, 0), (17, 28))
        self.imagens_frente.append(self.img)

        self.imagens_costas = []
        for x in range(4):
            img = ss_prot.subsurface((x * 17, 28), (17, 28))
            self.imagens_costas.append(img)
            self.todas_as_imagens.append(img)
        self.img = ss_prot.subsurface((0, 28), (17, 28))
        self.imagens_costas.append(self.img)

        self.imagens_esquerda = []
        for x in range(4):
            img = ss_prot.subsurface((x * 17, 56), (17, 28))
            self.imagens_esquerda.append(img)
            self.todas_as_imagens.append(img)
        self.img = ss_prot.subsurface((0, 56), (17, 28))
        self.imagens_esquerda.append(self.img)

        self.imagens_direita = []
        for x in range(4):
            img = ss_prot.subsurface((x * 17, 84), (17, 28))
            self.imagens_direita.append(img)
            self.todas_as_imagens.append(img)
        self.img = ss_prot.subsurface((0, 84), (17, 28))
        self.imagens_direita.append(self.img)

        self.tam_lista = len(self.todas_as_imagens)
        self.index_lista = 0.75
        self.image = self.todas_as_imagens[int(self.index_lista)]
        self.rect = self.image.get_rect()
        self.pos_x_inicial = largura // 2
        self.pos_y_inicial = altura // 2
        self.rect.midbottom = (self.pos_x_inicial, self.pos_y_inicial)

        self.velo_ani = 0.25

        self.vel_x = 0
        self.vel_y = 0

    def update(self):
        """if self.frente:
            if self.index_lista >= 4:
                self.index_lista = 0
            self.index_lista += self.velo_ani
            self.image = self.imagens_frente[int(self.index_lista)]
            self.frente = False

        if self.frente_solta:
            self.image = self.imagens_frente[0]
            if self.index_lista > 1:
                self.index_lista = 0
            self.frente_solta = False

        if self.costas:
            if self.index_lista >= 4:
                self.index_lista = 0
            self.index_lista += self.velo_ani
            self.image = self.imagens_costas[int(self.index_lista)]
            self.costas = False

        if self.costas_solta:
            self.image = self.imagens_costas[0]
            if self.index_lista > 1:
                self.index_lista = 0
            self.costas_solta = False

        if self.esquerda:
            if self.index_lista >= 4:
                self.index_lista = 0
            self.index_lista += self.velo_ani
            self.image = self.imagens_esquerda[int(self.index_lista)]
            self.esquerda = False

        if self.esquerda_solta:
            self.image = self.imagens_esquerda[0]
            if self.index_lista > 1:
                self.index_lista = 0
            self.esquerda_solta = False

        if self.direita:
            if self.index_lista >= 4:
                self.index_lista = 0
            self.index_lista += self.velo_ani
            self.image = self.imagens_direita[int(self.index_lista)]
            self.direita = False

        if self.direita_solta:
            self.image = self.imagens_direita[0]
            if self.index_lista > 1:
                self.index_lista = 0
            self.direita_solta = False"""
        colisoes = teste_colisao_mapa(self, TesteMapa01.layer_00, ["t"])
        if len(colisoes) == 0:
            self.rect.move_ip(self.vel_x, self.vel_y)

    def processar_evento(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == K_d:
                self.vel_x = 3
            if event.key == K_a:
                self.vel_x = -3
            if event.key == K_w:
                self.vel_y = -3
            if event.key == K_s:
                self.vel_y = 3
        if event.type == pygame.KEYUP:
            if event.key == K_d:
                self.vel_x = 0
            if event.key == K_a:
                self.vel_x = 0
            if event.key == K_w:
                self.vel_y = 0
            if event.key == K_s:
                self.vel_y = 0

# Mapa layer 00
img_grama = ss_grama.subsurface(((0, 0), (32, 32)))
img_terra = ss_terra.subsurface((32, 0), (32, 32))
layer_00 = pygame.sprite.Group()

# Sprites
todas_as_sprites = pygame.sprite.Group()
prot = Prot()
todas_as_sprites.add(prot)

while True:
    relogio.tick(FPS)
    tela.fill(branco)
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        prot.processar_evento(event)

    desenha_mapa(TesteMapa01.layer_00, {"g": img_grama, "t": img_terra})

    layer_00.draw(tela)
    todas_as_sprites.draw(tela)
    todas_as_sprites.update()
    pygame.display.flip()
