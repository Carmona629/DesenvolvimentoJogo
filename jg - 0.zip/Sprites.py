import pygame
import os
import constantes as cts

pygame.init()

# Mapa
class Mapa(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.speed_mov = 50
        self.mov_x = 0
        self.mov_y = 0

    def desenha_mapa(self, mapa, caracter_imagem, tela):
        for n_linha, linha in enumerate(mapa):
            for n_coluna, char in enumerate(linha):
                x = n_coluna * 32 + self.mov_x
                y = n_linha * 32 + self.mov_y
                self.img = caracter_imagem[char]
                tela.blit(self.img, (x, y))

    def mover_mapa(self):
        if pygame.key.get_pressed()[pygame.K_d]:
            self.mov_x -= self.speed_mov
        if pygame.key.get_pressed()[pygame.K_a]:
            self.mov_x += self.speed_mov
        if pygame.key.get_pressed()[pygame.K_s]:
            self.mov_y -= self.speed_mov
        if pygame.key.get_pressed()[pygame.K_w]:
            self.mov_y += self.speed_mov

# Personagem
class Personagem(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.ss_prot = pygame.image.load(os.path.join(cts.dir_imagens, "ss_prot.png")).convert_alpha()
        self.image = self.ss_prot.subsurface((0, 0), (17, 28))
        self.image = pygame.transform.scale(self.image, (17*3, 28*3))
        self.rect = self.image.get_rect()
        self.rect.center = (cts.LARGURA // 2, cts.ALTURA // 2)
