import pygame
import os
import constantes as cts
import Sprites

class Jogo():
    def __init__(self):
        # Criando tela
        pygame.init() # Inicia pygame
        pygame.mixer.init() # Inicia sons do pygame
        self.tela = pygame.display.set_mode((cts.LARGURA, cts.ALTURA), pygame.HWSURFACE) # Cria tela
        pygame.display.set_caption(cts.NOME_DA_TELA) # Define nome da tela
        self.relogio = pygame.time.Clock()
        self.fonte = pygame.font.match_font(cts.ARIAL) # Fonte usada
        self.carregar_arquivos() # Chama o módulo dos arquivos carregados quando a classe é instanciada
        self.jogando = True # Teste para loop do jogo
        self.pause = False

    def novo_jogo(self):
        # Instancia as classes das sprites do jogo
        self.todas_as_sprites = pygame.sprite.Group()
        self.layer00 = Sprites.Mapa()
        self.personagem = Sprites.Personagem()
        self.rodar()

    def rodar(self):
        # Loop principal do jogo
        while self.jogando:
            self.relogio.tick(cts.FPS)
            self.eventos()
            self.atualizar_sprites()
            self.desenhar_sprites()

    def eventos(self):
        # Define os eventos do jogo
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.jogando = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    self.tela_pause()
            self.layer00.mover_mapa()

    def atualizar_sprites(self):
        # Adiciona a sprite ao seu grupo
        self.todas_as_sprites.add(self.personagem)
        # Atualiza as sprites
        self.todas_as_sprites.update()

    def desenhar_sprites(self):
        # Desenha as sprites
        self.layer00.desenha_mapa(cts.LAYER00, {"g": self.grama, "t": self.terra}, self.tela)
        self.todas_as_sprites.draw(self.tela)  # Desenhando as sprites
        pygame.display.flip() # Atualiza a tela quando desenha as sprites
        self.tela.fill(cts.BRANCO) # Limpando a tela

    def carregar_arquivos(self):
        # Carrega arquivos de imagem
        dir_imagens = os.path.join(os.getcwd(), "Imagens")
        self.grama = cts.pega_imagem(cts.SS_GRAMA)
        self.terra = cts.pega_imagem(cts.SS_TERRA)
        # Carrega arquivos de som
        self.dir_sons = os.path.join(os.getcwd(), "Sons")

    def mostrar_texto(self, tamanho, texto, cor, x, y):
        # Exibe uma mensagem na tela
        fonte = pygame.font.Font(self.fonte, tamanho)
        texto = fonte.render(texto, True, cor)
        texto_rect = texto.get_rect()
        texto_rect.midtop = (x, y)
        self.tela.blit(texto, texto_rect)

    def tela_pause(self):
        self.pause = True
        while self.pause:
            self.relogio.tick(cts.FPS)
            self.layer00.desenha_mapa(cts.LAYER00, {"g": self.grama, "t": self.terra}, self.tela)
            self.todas_as_sprites.draw(self.tela)
            self.mostrar_texto(40, "PAUSE", cts.PRETO, cts.LARGURA // 2, cts.ALTURA // 2)
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.pause = False
                    self.jogando = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        self.pause = False

jogo = Jogo()

while jogo.jogando:
    jogo.novo_jogo()