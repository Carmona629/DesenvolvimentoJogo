import pygame
import os

# Cores
VERMELHO = (255, 0, 0)
VERDE = (0, 255, 0)
AZUL = (0, 0, 255)
AMARELO = (254, 223, 0)
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)

# Parâmetros tela
NOME_DA_TELA = "Teste02"
LARGURA = 1024
ALTURA = 768
FPS = 60

# Imagens
dir_imagens = os.path.join(os.path.dirname(__file__), "Imagens")
ICON_TELA = "icon_tela.png"
LOGO = "icon_tela.png"
SS_PROT = "ss_prot.png"
SS_GRAMA = "ss_grama.png"
SS_TERRA = "ss_terra.png"

# Layer00
LAYER00 = ["gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "ggggggggggggggggggggtggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg",
           "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg"
           ]

def pega_imagem(nome_imagem):
    img = pygame.image.load(os.path.join(dir_imagens, nome_imagem)).convert_alpha()
    img = img.subsurface((0, 0), (32, 32))
    return img

# Fontes
ARIAL = "arial"