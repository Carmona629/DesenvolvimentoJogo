import pygame
import os
import constantes as cts
import Sprites

class Jogo():
    def __init__(self):
        # Criando tela
        pygame.init() # Inicia pygame
        pygame.mixer.init() # Inicia sons do pygame
        self.tela = pygame.display.set_mode((cts.LARGURA, cts.ALTURA), pygame.HWSURFACE) # Cria tela
        pygame.display.set_caption(cts.NOME_DA_TELA) # Define nome da tela
        self.relogio = pygame.time.Clock()
        self.fonte = pygame.font.match_font(cts.ARIAL) # Fonte usada
        self.carregar_arquivos() # Chama o módulo dos arquivos carregados quando a classe é instanciada
        self.jogando = True # Teste para loop do jogo
        self.pause = False
        self.jogar = False

    def novo_jogo(self):
        # Instancia as classes das sprites do jogo
        self.tela_inicial()
        self.todas_as_sprites = pygame.sprite.Group()
        self.layer00 = Sprites.Mapa()
        self.personagem = Sprites.Personagem()
        self.rodar()

    def rodar(self):
        # Loop principal do jogo
        while self.jogando:
            if self.jogar:
                self.relogio.tick(cts.FPS)
                self.eventos()
                self.atualizar_sprites()
                self.desenhar_sprites()

    def eventos(self):
        # Define os eventos do jogo
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.jogando = False
                if self.pause:
                    self.pause = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_KP_ENTER:
                    self.tela_pause()
            self.layer00.mover_mapa(event)

    def atualizar_sprites(self):
        # Adiciona a sprite ao seu grupo
        self.todas_as_sprites.add(self.personagem)
        # Atualiza as sprites
        self.todas_as_sprites.update()

    def desenhar_sprites(self):
        # Desenha as sprites
        self.layer00.desenha_mapa(cts.LAYER00, {"g": self.grama, "t": self.terra}, self.tela)
        self.todas_as_sprites.draw(self.tela)  # Desenhando as sprites
        pygame.display.flip() # Atualiza a tela quando desenha as sprites
        self.tela.fill(cts.BRANCO) # Limpando a tela

    def carregar_arquivos(self):
        # Carrega arquivos de imagem
        dir_imagens = os.path.join(os.getcwd(), "Imagens")
        self.grama = cts.pega_imagem(cts.SS_GRAMA)
        self.terra = cts.pega_imagem(cts.SS_TERRA)
        self.logo = os.path.join(dir_imagens, cts.LOGO)
        self.logo = pygame.image.load(self.logo).convert_alpha()
        self.logo = pygame.transform.scale(self.logo, (17*10, 28*10))
        self.escolhedor = os.path.join(dir_imagens, cts.SS_PROT)
        self.escolhedor = pygame.image.load(self.escolhedor).convert_alpha()
        # Carrega arquivos de som
        self.dir_sons = os.path.join(os.getcwd(), "Sons")

    def mostrar_texto(self, tamanho, texto, cor, x, y, neg):
        # Exibe uma mensagem na tela
        fonte = pygame.font.SysFont(self.fonte, tamanho, neg)
        texto = fonte.render(texto, True, cor)
        texto_rect = texto.get_rect()
        texto_rect.midtop = (x, y)
        self.tela.blit(texto, texto_rect)

    def mostrar_logo(self, x, y):
        start_logo_rect = self.logo.get_rect()
        start_logo_rect.midtop = (x, y)
        self.tela.blit(self.logo, start_logo_rect)

    def desenhar_seta(self, pos_x, pos_y):
        self.setas = pygame.sprite.Group()
        self.seta_inicial = Sprites.setas(pos_x, pos_y)
        self.setas.add(self.seta_inicial)
        self.setas.draw(self.tela)

    def tela_inicial(self):
        self.y = (cts.ALTURA // 2) + 10
        while not self.jogar:
            self.relogio.tick(cts.FPS)
            self.tela.fill(cts.AMARELO)
            # Opções do menu
            self.mostrar_texto(40, "Começar", cts.PRETO, cts.LARGURA // 2, cts.ALTURA // 2, True)
            self.mostrar_texto(40, "Sair", cts.PRETO, cts.LARGURA // 2, 420, True)
            self.mostrar_texto(22, "Desenvolvido por Guilherme Carmona", cts.PRETO, cts.LARGURA // 2, cts.ALTURA - 20, False)
            # Img_logo
            self.mostrar_logo(cts.LARGURA // 2, 20)
            # Seleção
            self.desenhar_seta(420, self.y)
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.jogar = True
                    self.jogando = False
                if event.type == pygame.KEYDOWN:
                    # Movimentos seleção
                    if event.key == pygame.K_s:
                        self.y += 35
                        if self.y > 429:
                            self.y = (cts.ALTURA // 2) + 10
                    if event.key == pygame.K_w:
                        self.y -= 35
                        if self.y < (cts.ALTURA // 2) + 10:
                            self.y = 429
                    # Escolha das opções do menu
                    if event.key == pygame.K_KP_ENTER:
                        if self.y == (cts.ALTURA // 2) + 10:
                            self.jogar = True
                        if self.y == 429:
                            self.jogar = True
                            self.jogando = False

    def tela_pause(self):
        self.pause = True
        pos_x = [40, 210, 400, 550, 710, 885]
        i = 0
        self.x = pos_x[i]
        while self.pause:
            self.relogio.tick(cts.FPS)
            self.layer00.desenha_mapa(cts.LAYER00, {"g": self.grama, "t": self.terra}, self.tela)
            self.todas_as_sprites.draw(self.tela)
            self.mostrar_texto(60, "PAUSE", cts.PRETO, cts.LARGURA // 2, 10, False)
            pygame.draw.rect(self.tela, cts.AMARELO, (0, cts.ALTURA - 40, cts.LARGURA, 40))
            self.mostrar_texto(26, "RETORNAR", cts.PRETO, 100, cts.ALTURA - 29, False)
            self.mostrar_texto(26, "INVENTÁRIO", cts.PRETO, 280, cts.ALTURA - 30, False)
            self.mostrar_texto(26, "INFO", cts.PRETO, 440, cts.ALTURA - 29, False)
            self.mostrar_texto(26, "CONFIG", cts.PRETO, 600, cts.ALTURA - 29, False)
            self.mostrar_texto(26, "SALVAR", cts.PRETO, 760, cts.ALTURA - 29, False)
            self.mostrar_texto(26, "SAIR", cts.PRETO, 920, cts.ALTURA - 29, False)
            self.desenhar_seta(self.x, cts.ALTURA - 25)
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.pause = False
                    self.jogando = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_d:
                        i += 1
                        if i > len(pos_x) - 1:
                            i = 0
                        self.x = pos_x[i]
                    if event.key == pygame.K_a:
                        i -= 1
                        if i < 0:
                            i = len(pos_x) - 1
                        self.x = pos_x[i]
                    if event.key == pygame.K_KP_ENTER:
                        if i == 0:
                            self.pause = False

                        """if i == 1:
                            pass

                        if i == 2:
                            pass

                        if i == 3:
                            pass

                        if i == 4:
                            pass"""

                        if i == 5:
                            self.pause = False
                            self.jogando = False

    def inventario(self):
        pass

jogo = Jogo()

while jogo.jogando:
    jogo.novo_jogo()